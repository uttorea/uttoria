import "./frame-component.css";

const FrameComponent = () => {
  return (
    <footer className="vector-parent">
      <img
        className="instance-child"
        loading="lazy"
        alt=""
        src="/vector-10.svg"
      />
      <div className="frame-group">
        <div className="frame-wrapper">
          <div className="frame-container">
            <img
              className="frame-icon"
              loading="lazy"
              alt=""
              src="/frame-56@2x.png"
            />
            <div className="frame-wrapper1">
              <div className="frame-parent1">
                <div className="uttorea-wrapper">
                  <div className="uttorea">Uttorea</div>
                </div>
                <img className="line-icon" loading="lazy" alt="" />
                <div className="rescue-safety-systems-wrapper">
                  <div className="rescue-safety">{`Rescue & Safety systems`}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="footer-ui-wrapper">
          <div className="footer-ui">
            <div className="frame-parent2">
              <div className="logo-and-contact-email-wrapper">
                <div className="logo-and-contact-email">
                  <div className="logo-placeholder">+91 721 928 6003</div>
                </div>
              </div>
              <div className="quick-links-wrapper">
                <div className="quick-links">
                  <div className="employee-database-parent">
                    <b className="employee-database">Product</b>
                    <div className="multirotor-drone-fixed-container">
                      <p className="multirotor-drone">Multirotor Drone</p>
                      <p className="fixed-wing-drone">Fixed wing Drone</p>
                    </div>
                  </div>
                  <div className="employee-database-group">
                    <b className="employee-database1">Services</b>
                    <div className="custom-drone-recovery">
                      Custom Drone Recovery system
                    </div>
                  </div>
                </div>
              </div>
              <div className="subscribe">
                <b className="product">Office</b>
              </div>
            </div>
            <div className="footer-ui-inner">
              <div className="divider-parent">
                <div className="divider" />
                <div className="content-under-divider">
                  <div className="social-links">
                    <div className="facebook-parent">
                      <img
                        className="facebook-icon"
                        loading="lazy"
                        alt=""
                        src="/facebook.svg"
                      />
                      <img
                        className="linkedin-icon"
                        loading="lazy"
                        alt=""
                        src="/linkedin.svg"
                      />
                    </div>
                  </div>
                  <div className="content-under-divider-inner">
                    <div className="pricing-wrapper">
                      <div className="pricing">
                        © 2024 UTTOREA. All rights reserved
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="salesuttoreacom1">sales@uttorea.com</div>
            <div className="djac-siic-building2">
              DJAC, SIIC building, IIT Kanpur 208016
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default FrameComponent;
